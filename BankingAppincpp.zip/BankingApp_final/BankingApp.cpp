#include "BankingApp.h"

// Constructor
BankingApp::BankingApp(double initialAmount, double monthlyDeposit, double annualInterest, int years) {
    m_initialAmount = initialAmount;
    m_monthlyDeposit = monthlyDeposit;
    m_annualInterest = annualInterest;
    m_numberOfYears = years;
}

// Function to display the data input
void BankingApp::displayDataInput() const {
    cout << "\n**********************************" << endl;
    cout << "********** Data Input ************" << endl;
    cout << "Initial Investment Amount:  $" << fixed << setprecision(2) << m_initialAmount << endl;
    cout << "Monthly Deposit:  $" << m_monthlyDeposit << endl;
    cout << "Annual Interest:  %" << m_annualInterest << endl;
    cout << "Number of years:  " << m_numberOfYears << endl;
    cout << "Press any key to continue . . .\n";
    _getch(); // Wait for the user to press any key
}

// Function to print details
void BankingApp::printDetails(int yearIndex, double balance, double interestEarnedThisYear) const {
    cout << setw(6) << yearIndex << setw(17) << "$" << fixed << setprecision(2) << balance << setw(24) << "$" << interestEarnedThisYear << endl << endl;
}

// Function to calculate the balance and interest without additional monthly deposits
double BankingApp::calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears) const {
    double openingAmount = initialInvestment;
    double interest = interestRate / 100;
    double monthlyInterest = interest / 12;
    double totalInterest;
    double interestEarned;

    for (int i = 1; i <= numberOfYears; i++) {
        totalInterest = 0.0;
        for (int j = 0; j < 12; j++) {
            interestEarned = openingAmount * monthlyInterest;
            totalInterest += interestEarned;
            openingAmount += interestEarned;
        }
        printDetails(i, openingAmount, totalInterest);
    }

    return openingAmount;
}

// Function to calculate the balance and interest with additional monthly deposits
double BankingApp::balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) const {
    double openingAmount = initialInvestment;
    double interest = interestRate / 100;
    double monthlyInterest = interest / 12;
    double totalInterest;
    double interestEarned;

    for (int i = 1; i <= numberOfYears; i++) {
        totalInterest = 0.0;
        for (int j = 0; j < 12; j++) {
            interestEarned = (openingAmount + monthlyDeposit) * monthlyInterest;
            openingAmount += monthlyDeposit;
            totalInterest += interestEarned;
            openingAmount += interestEarned;
        }
        printDetails(i, openingAmount, totalInterest);
    }
    return openingAmount;
}

// Function to display the report
void BankingApp::displayReport() const {
    displayDataInput();

    // Calculate without deposits
    cout << "\n  Balance and Interest Without Additional Monthly Deposits   " << endl;
    cout << "=============================================================" << endl;
    cout << "  Year        Year End Balance     Year End Earned Interest  " << endl;
    cout << "-------------------------------------------------------------" << endl;
    calculateBalanceWithoutMonthlyDeposit(m_initialAmount, m_annualInterest, m_numberOfYears);

    // Calculate with deposits
    cout << "\n   Balance and Interest With Additional Monthly Deposits   " << endl;
    cout << "=============================================================" << endl;
    cout << "  Year        Year End Balance     Year End Earned Interest  " << endl;
    cout << "-------------------------------------------------------------" << endl;
    balanceWithMonthlyDeposit(m_initialAmount, m_monthlyDeposit, m_annualInterest, m_numberOfYears);
}

int main() {
    double initialAmount, monthlyDeposit, annualInterest;
    int years;

    cout << "**********************************" << endl;
    cout << "********** Data Input ************" << endl;
    while (true) {
        cout << "Initial Investment Amount: ";
        cin >> initialAmount;
        if (initialAmount >= 0) break;
        cout << "Invalid input. Please enter a value greater than or equal to zero.\n";
    }

    while (true) {
        cout << "Monthly Deposit: ";
        cin >> monthlyDeposit;
        if (monthlyDeposit >= 0) break;
        cout << "Invalid input. Please enter a value greater than or equal to zero.\n";
    }

    while (true) {
        cout << "Annual Interest: ";
        cin >> annualInterest;
        if (annualInterest >= 0) break;
        cout << "Invalid input. Please enter a value greater than or equal to zero.\n";
    }

    while (true) {
        cout << "Number of years: ";
        cin >> years;
        if (years >= 0) break;
        cout << "Invalid input. Please enter a value greater than or equal to zero.\n";
    }

    cout << "Press any key to continue . . ." << endl;
    _getch(); // Wait for the user to press any key

    // Create an object of the BankingApp class
    BankingApp app(initialAmount, monthlyDeposit, annualInterest, years);
    app.displayReport();

    return 0;
}
