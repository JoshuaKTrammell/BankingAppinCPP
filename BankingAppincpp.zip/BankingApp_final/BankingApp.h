#ifndef BANKINGAPP_H
#define BANKINGAPP_H

#include <iostream>
#include <iomanip>
#include <cmath>
#include <conio.h>

using namespace std;

class BankingApp {
private:
    double m_initialAmount;
    double m_monthlyDeposit;
    double m_annualInterest;
    int m_numberOfYears;

public:
    // Constructor
    BankingApp(double initialAmount, double monthlyDeposit, double annualInterest, int years);

    // Function to display the data input
    void displayDataInput() const;

    // Function to calculate the balance and interest without additional monthly deposits
    double calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears) const;

    // Function to calculate the balance and interest with additional monthly deposits
    double balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) const;

    // Function to print details
    void printDetails(int yearIndex, double balance, double interestEarnedThisYear) const;

    // Function to display the report
    void displayReport() const;
};

#endif // BANKINGAPP_H
